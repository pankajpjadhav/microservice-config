package com.user.service.UserService;

import com.user.service.UserService.entities.Rating;
import com.user.service.UserService.external.services.RatingService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Service;

@Service
@SpringBootTest
class UserServiceApplicationTests {

	@Autowired
	private RatingService ratingService;

	@Test
	void contextLoads() {
	}

//	@Test
//	public void createRating(){
//		Rating rating=Rating.builder().rating(10).userId("").hotelId("").feedback("Nice hotel").build();
//		Rating rating1 = ratingService.createRating(rating);
//		System.out.println("new rating created");
//	}
//
//	public void updateRating(){
//		String ratingId="fd861cb3-809a-41c3-83bc-ec072c6693c3";
//		if()
//	}
//
//	@Test
//	public void deleteRating(){
//		String ratingId="fd861cb3-809a-41c3-83bc-ec072c6693c3";
//		String s = ratingService.deleteRating(ratingId);
//		System.out.println("deleted");
//	}

}
