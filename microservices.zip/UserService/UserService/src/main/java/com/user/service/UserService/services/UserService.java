package com.user.service.UserService.services;

import com.user.service.UserService.entities.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    //User Operations

    //create
    User saveUser(User user);

    //get all users
    List<User> getAllUsers();

    //get single user by userID
    User getUser(String userId);

    //delete single user by userId
    String deleteUser(String userId);

    //update user
//    User updateUser(String userId,User user);
}
