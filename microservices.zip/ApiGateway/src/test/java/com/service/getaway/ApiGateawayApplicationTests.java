package com.service.getaway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGateawayApplicationTests {

	@Test
	void contextLoads() {
	}

}
