package com.service.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGateawayApplicationTests {

	@Test
	void contextLoads() {
	}

}
