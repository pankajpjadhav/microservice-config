package com.hotel.service.HotelService.services;

import com.hotel.service.HotelService.entities.Hotel;

import java.util.List;

public interface HotelService {

    //create hotel
    Hotel createHotel(Hotel hotel);

    //getAll hotels
    List<Hotel> getAllHotels();

    //getSingleHotel
    Hotel getHotel(String id);

    //deleteHotel
    String deleteHotel(String id);
}
