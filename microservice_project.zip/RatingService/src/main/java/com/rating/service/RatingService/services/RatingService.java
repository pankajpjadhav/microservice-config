package com.rating.service.RatingService.services;

import com.rating.service.RatingService.entities.Rating;

import java.util.List;

public interface RatingService {

    //create
    Rating create(Rating rating);

    //get Rating by userId
    List<Rating> getRatingByUserId(String userId);

    //get ratings by hotel id
    List<Rating> getRatingByHotelId(String hotelId);

    //get all ratings
    List<Rating> getAllRatings();

    //delete rating
    String deleteRating(String ratingId);
}
